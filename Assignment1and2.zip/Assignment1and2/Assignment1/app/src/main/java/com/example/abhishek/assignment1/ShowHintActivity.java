package com.example.abhishek.assignment1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ShowHintActivity extends AppCompatActivity {
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_hint);
        MainActivity.checkCheat = true;
        //Toast.makeText(getApplicationContext(), "The flag has been set to"  , Toast.LENGTH_LONG).show();
        textView = (TextView)findViewById(R.id.HintText);
        textView.setTextSize(40);
        textView.setText(" Hint");
    }
}
