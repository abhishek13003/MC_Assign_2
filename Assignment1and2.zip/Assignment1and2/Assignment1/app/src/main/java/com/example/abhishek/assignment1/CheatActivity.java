package com.example.abhishek.assignment1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class CheatActivity extends AppCompatActivity {
    TextView random_Text;
    TextView cheat_Text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cheat2);
        MainActivity.checkCheat = true;

        //Toast.makeText(getApplicationContext(), "The flag has been set to"  , Toast.LENGTH_LONG).show();
        cheat_Text = (TextView)findViewById(R.id.CheatText);
        random_Text = (TextView) findViewById(R.id.RandomText);
        cheat_Text.setTextSize(40);
        int rand_no = getIntent().getExtras().getInt("number");
        random_Text.setText(" "+ rand_no);
        if(MainActivity.isprime == 11)
        {
            cheat_Text.setText("This number is NOT prime! ");
        }
        if(MainActivity.isprime == 111)
        {
            cheat_Text.setText("This number is prime!! ");
        }

    }
}

